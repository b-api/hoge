package jp.co.nttdata.policyeditor;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JSplitPane;
import java.awt.GridLayout;
import javax.swing.JTable;
import java.awt.BorderLayout;
import javax.swing.JTabbedPane;
import javax.swing.JButton;
import javax.swing.JToolBar;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;

public class MainView extends JFrame {

	private final int splitDividerLocation_1 = 300;
	private final int splitDividerLocation_2 = 400;
	private JPanel contentPane;

	private String[] columnNames = {"id", "SSID", "MAC"};
	private String[][] tabledata = {
			{"wap_1", "Toyosu_2F", "00:00:00:00:00:00"},
			{"wap_2", "Toyosu_11F", "FF:FF:FF:FF:FF:FF"}};

	private String[] columnNames1 = {"id", "対象WiFiAP"};
	private String[][] tabledata1 = {
			{"ctl_wf_1", "wap_1,wap_2"}};

	private JTable table;
	private JTable table_1;
	private JTable table_2;
	private JTable table_3;
	private JLabel wifiAPLabel;
	private JTable table_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainView frame = new MainView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainView() {
		setTitle("動的制御ポリシーファイルエディタ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu menu = new JMenu("ファイル");
		menuBar.add(menu);

		JMenu menu_1 = new JMenu("編集");
		menuBar.add(menu_1);

		JMenu menu_2 = new JMenu("ヘルプ");
		menuBar.add(menu_2);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JToolBar toolBar = new JToolBar();
		contentPane.add(toolBar, BorderLayout.NORTH);

		JButton btnNewButton = new JButton("New button");
		toolBar.add(btnNewButton);

		JSplitPane splitPane = new JSplitPane();
		splitPane.setDividerLocation(splitDividerLocation_1);
		contentPane.add(splitPane, BorderLayout.CENTER);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		splitPane.setLeftComponent(tabbedPane);

		JPanel panel = new JPanel();
		panel.setBorder(null);
		tabbedPane.addTab("Wi-Fi AP", null, panel, null);
		panel.setLayout(new GridLayout(2, 1, 0, 0));

		/* WiFiAPテーブル */
		JPanel panel_4 = new JPanel();
		panel.add(panel_4);
		panel_4.setLayout(new BorderLayout(0, 0));

		wifiAPLabel = new JLabel("Wi-Fi AP テーブル");
		panel_4.add(wifiAPLabel, BorderLayout.NORTH);

		JScrollPane scrollPane = new JScrollPane();
		panel_4.add(scrollPane);

		DefaultTableModel tableModel = new DefaultTableModel(columnNames,0);
		for(int i = 0 ; i < tabledata.length ; i++){
			tableModel.addRow(tabledata[i]);
		}
		table_1 = new JTable(tableModel);
		scrollPane.setViewportView(table_1);
		table_1.setBorder(null);

		JPanel panel_5 = new JPanel();
		panel_4.add(panel_5, BorderLayout.EAST);
		panel_5.setLayout(new BoxLayout(panel_5, BoxLayout.Y_AXIS));

		JButton btnNewButton_3 = new JButton("追加");
		panel_5.add(btnNewButton_3);

		JButton btnNewButton_4 = new JButton("削除");
		panel_5.add(btnNewButton_4);

		JButton btnNewButton_5 = new JButton("上へ");
		panel_5.add(btnNewButton_5);

		JButton btnNewButton_6 = new JButton("下へ");
		panel_5.add(btnNewButton_6);

		JPanel panel_2 = new JPanel();
		panel.add(panel_2);
		panel_2.setLayout(new BorderLayout(0, 0));

		JButton btnNewButton_1 = new JButton("選択済WiFiAPのグループ登録");
		panel_2.add(btnNewButton_1, BorderLayout.NORTH);

		/* WiFiAPリストテーブル */
		JPanel panel_6 = new JPanel();
		panel_2.add(panel_6, BorderLayout.CENTER);
		panel_6.setLayout(new BorderLayout(0, 0));

		JLabel wifiAPListLabel = new JLabel("WiFi AP リスト テーブル");
		panel_6.add(wifiAPListLabel, BorderLayout.NORTH);

		JScrollPane scrollPane_1 = new JScrollPane();
		panel_6.add(scrollPane_1, BorderLayout.CENTER);

		DefaultTableModel tableModel1 = new DefaultTableModel(columnNames1,0);
		for(int i = 0 ; i < tabledata1.length ; i++){
			tableModel1.addRow(tabledata1[i]);
		}
		table = new JTable(tableModel1);
		scrollPane_1.setViewportView(table);

		JPanel panel_7 = new JPanel();
		panel_6.add(panel_7, BorderLayout.EAST);
		panel_7.setLayout(new BoxLayout(panel_7, BoxLayout.Y_AXIS));

		JButton btnNewButton_7 = new JButton("削除");
		panel_7.add(btnNewButton_7);

		JButton btnNewButton_8 = new JButton("上へ");
		panel_7.add(btnNewButton_8);

		JButton btnNewButton_9 = new JButton("下へ");
		panel_7.add(btnNewButton_9);

		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("アプリケーション", null, panel_1, null);
		panel_1.setLayout(new GridLayout(2, 1, 0, 0));

		JPanel panel_3 = new JPanel();
		panel_1.add(panel_3);
		panel_3.setLayout(new BorderLayout(0, 0));

		JLabel label = new JLabel("New label");
		panel_3.add(label, BorderLayout.NORTH);

		JScrollPane scrollPane_2 = new JScrollPane();
		panel_3.add(scrollPane_2, BorderLayout.CENTER);

		table_2 = new JTable();
		scrollPane_2.setViewportView(table_2);

		JPanel panel_9 = new JPanel();
		panel_3.add(panel_9, BorderLayout.EAST);
		panel_9.setLayout(new BoxLayout(panel_9, BoxLayout.Y_AXIS));

		JButton btnNewButton_2 = new JButton("New button");
		panel_9.add(btnNewButton_2);

		JButton btnNewButton_10 = new JButton("New button");
		panel_9.add(btnNewButton_10);

		JButton btnNewButton_11 = new JButton("New button");
		panel_9.add(btnNewButton_11);

		JButton btnNewButton_12 = new JButton("New button");
		panel_9.add(btnNewButton_12);

		JPanel panel_8 = new JPanel();
		panel_1.add(panel_8);
		panel_8.setLayout(new BorderLayout(0, 0));

		JButton btnNewButton_13 = new JButton("New button");
		panel_8.add(btnNewButton_13, BorderLayout.NORTH);

		JPanel panel_10 = new JPanel();
		panel_8.add(panel_10, BorderLayout.CENTER);
		panel_10.setLayout(new BorderLayout(0, 0));

		JLabel lblNewLabel_2 = new JLabel("New label");
		panel_10.add(lblNewLabel_2, BorderLayout.NORTH);

		JScrollPane scrollPane_3 = new JScrollPane();
		panel_10.add(scrollPane_3, BorderLayout.CENTER);

		table_3 = new JTable();
		scrollPane_3.setViewportView(table_3);

		JPanel panel_11 = new JPanel();
		panel_10.add(panel_11, BorderLayout.EAST);
		panel_11.setLayout(new BoxLayout(panel_11, BoxLayout.Y_AXIS));

		JButton btnNewButton_14 = new JButton("New button");
		panel_11.add(btnNewButton_14);

		JButton btnNewButton_15 = new JButton("New button");
		panel_11.add(btnNewButton_15);

		JButton btnNewButton_16 = new JButton("New button");
		panel_11.add(btnNewButton_16);

		JSplitPane splitPane_1 = new JSplitPane();
		splitPane_1.setDividerLocation(splitDividerLocation_2);
		splitPane_1.setOrientation(JSplitPane.VERTICAL_SPLIT);
		splitPane.setRightComponent(splitPane_1);

		JPanel panel_12 = new JPanel();
		splitPane_1.setLeftComponent(panel_12);
		panel_12.setLayout(new BorderLayout(0, 0));

		JLabel lblNewLabel = new JLabel("登録済みポリシー");
		panel_12.add(lblNewLabel, BorderLayout.NORTH);

		JPanel panel_13 = new JPanel();
		panel_12.add(panel_13, BorderLayout.EAST);
		panel_13.setLayout(new BoxLayout(panel_13, BoxLayout.Y_AXIS));

		JButton btnNewButton_17 = new JButton("追加");
		panel_13.add(btnNewButton_17);

		JButton btnNewButton_18 = new JButton("削除");
		panel_13.add(btnNewButton_18);

		JButton btnNewButton_19 = new JButton("上へ");
		panel_13.add(btnNewButton_19);

		JButton btnNewButton_20 = new JButton("下へ");
		panel_13.add(btnNewButton_20);

		JScrollPane scrollPane_4 = new JScrollPane();
		panel_12.add(scrollPane_4, BorderLayout.CENTER);

		table_4 = new JTable();
		scrollPane_4.setViewportView(table_4);

		JPanel panel_14 = new JPanel();
		splitPane_1.setRightComponent(panel_14);
		panel_14.setLayout(new GridLayout(1, 2, 0, 0));

		JPanel panel_15 = new JPanel();
		panel_14.add(panel_15);
		panel_15.setLayout(new BorderLayout(0, 0));

		JLabel lblNewLabel_1 = new JLabel("条件の指定");
		panel_15.add(lblNewLabel_1, BorderLayout.NORTH);

		JPanel panel_17 = new JPanel();
		panel_15.add(panel_17, BorderLayout.CENTER);
		panel_17.setLayout(new GridLayout(4, 2, 0, 0));

		JLabel lblNewLabel_4 = new JLabel("認証");
		panel_17.add(lblNewLabel_4);

		JComboBox comboBox = new JComboBox();
		panel_17.add(comboBox);

		JLabel lblNewLabel_5 = new JLabel("場所");
		panel_17.add(lblNewLabel_5);

		JComboBox comboBox_1 = new JComboBox();
		panel_17.add(comboBox_1);

		JLabel lblNewLabel_6 = new JLabel("時間");
		panel_17.add(lblNewLabel_6);

		JPanel panel_18 = new JPanel();
		panel_18.setBorder(null);
		panel_17.add(panel_18);
		panel_18.setLayout(new GridLayout(1, 3, 0, 0));

		JComboBox comboBox_2 = new JComboBox();
		panel_18.add(comboBox_2);

		JLabel lblNewLabel_8 = new JLabel("~");
		lblNewLabel_8.setHorizontalAlignment(JLabel.CENTER);
		panel_18.add(lblNewLabel_8);

		JComboBox comboBox_3 = new JComboBox();
		panel_18.add(comboBox_3);

		JLabel lblNewLabel_7 = new JLabel("接続WiFi");
		panel_17.add(lblNewLabel_7);

		JComboBox comboBox_4 = new JComboBox();
		panel_17.add(comboBox_4);

		JPanel panel_16 = new JPanel();
		panel_14.add(panel_16);
		panel_16.setLayout(new BorderLayout(0, 0));

		JLabel lblNewLabel_3 = new JLabel("制御の指定");
		panel_16.add(lblNewLabel_3, BorderLayout.NORTH);

		JPanel panel_19 = new JPanel();
		panel_16.add(panel_19, BorderLayout.CENTER);
		panel_19.setLayout(new GridLayout(4, 2, 0, 0));

		JLabel lblNewLabel_9 = new JLabel("アプリケーション");
		panel_19.add(lblNewLabel_9);

		JComboBox comboBox_5 = new JComboBox();
		panel_19.add(comboBox_5);

		JLabel lblNewLabel_10 = new JLabel("WiFi");
		panel_19.add(lblNewLabel_10);

		JComboBox comboBox_6 = new JComboBox();
		panel_19.add(comboBox_6);

		JLabel lblNewLabel_11 = new JLabel("カメラ");
		panel_19.add(lblNewLabel_11);

		JComboBox comboBox_7 = new JComboBox();
		panel_19.add(comboBox_7);

		JLabel lblNewLabel_12 = new JLabel("画面切り替え");
		panel_19.add(lblNewLabel_12);

		JComboBox comboBox_8 = new JComboBox();
		panel_19.add(comboBox_8);
	}

}
